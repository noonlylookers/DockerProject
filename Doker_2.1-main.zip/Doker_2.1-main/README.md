# Запуск контейнера
docker compose up -d

